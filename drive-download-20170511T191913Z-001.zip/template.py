from pyspark.sql.functions import *
import csv
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark import SparkContext
from pyspark.sql import HiveContext
from pyspark.sql.functions import *
from pyspark.sql.functions import udf
from pyspark.sql.types import BooleanType
from pyspark.sql import Row
import csv
from pyspark.sql import SQLContext




def main(sc):
	spark = HiveContext(sc)
	sqlContext = HiveContext(sc)
	rows = sc.textFile('../../lmf445/Flight_Project/Data/864625436_T_ONTIME_*2.csv').mapPartitionsWithIndex(parseCSV)
	df = sqlContext.createDataFrame(rows)
	
	departure_time_pivot.toPandas().to_csv('big_data_project/data/most_common_departure_time.csv')

if __name__ == "__main__":
    sc = SparkContext()
    main(sc)