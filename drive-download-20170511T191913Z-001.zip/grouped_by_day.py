from pyspark.sql.functions import *
import csv
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark import SparkContext
from pyspark.sql import HiveContext
from pyspark.sql.functions import *
from pyspark.sql.functions import udf
from pyspark.sql.types import BooleanType
from pyspark.sql import Row
import csv
from pyspark.sql import SQLContext

def parseCSV(idx, part):
    if idx==0:
        part.next()
    for p in csv.reader(part):
		if p[14] == 'ORIGIN':
			pass
		else:
			yield Row(FL_DATE = p[5],
	                      ORIGIN=p[14],
	                      ORIGIN_AIRPORT_ID = p[11],
	                      DEST = p[23],
	                      DEST_AIRPORT_ID = p[20])

def main(sc):
	spark = HiveContext(sc)
	sqlContext = HiveContext(sc)
	rows = sc.textFile('../lmf445/Flight_Project/Data/864625436_T_ONTIME_*2.csv').mapPartitionsWithIndex(parseCSV)
	df = sqlContext.createDataFrame(rows)

	grouped_by_day = df.groupBy('FL_DATE').count()

	grouped_by_day.toPandas().to_csv('big_data_project/data/grouped_by_day.csv')

if __name__ == "__main__":
    sc = SparkContext()
    main(sc)
