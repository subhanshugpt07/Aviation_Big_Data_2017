from pyspark.sql.functions import *
import csv
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark import SparkContext
from pyspark.sql import HiveContext
from pyspark.sql.functions import *
from pyspark.sql.functions import udf
from pyspark.sql.types import BooleanType
from pyspark.sql import Row
import csv
from pyspark.sql import SQLContext

def parseCSV(idx, part):
    if idx==0:
        part.next()
    for p in csv.reader(part):
        if p[0] == '2014':
            yield Row(YEAR = p[0],
                      MONTH = int(p[2]),
                      DEP_TIME_BLK = p[35],
                      DEST_CITY_NAME = p[24])
        elif p[0] == '2015':
            yield Row(YEAR = p[0],
                      MONTH = int(p[2])+12,
                      DEP_TIME_BLK = p[35],
                      DEST_CITY_NAME = p[24])
        elif p[0] == '2016':
            yield Row(YEAR = p[0],
                      MONTH = int(p[2])+24,
                      DEP_TIME_BLK = p[35],
                      DEST_CITY_NAME = p[24])
        else:
            pass
        
		
def main(sc):
	spark = HiveContext(sc)
    sqlContext = HiveContext(sc)
	rows = sc.textFile('../lmf445/Flight_Project/Data/864625436_T_ONTIME_*2.csv').mapPartitionsWithIndex(parseCSV)
    df = sqlContext.createDataFrame(rows)
	
	departure_time_pivot = \
		df.groupBy('DEP_TIME_BLK').pivot('MONTH').count()
	
	departure_time_pivot.toPandas().to_csv('most_common_departure_time.csv')
	
if __name__ == "__main__":
    sc = SparkContext()
    main(sc)