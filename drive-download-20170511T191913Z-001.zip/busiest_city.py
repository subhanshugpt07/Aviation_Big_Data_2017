from pyspark.sql.functions import *
import csv
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark import SparkContext
from pyspark.sql import HiveContext
from pyspark.sql.functions import *
from pyspark.sql.functions import udf
from pyspark.sql.types import BooleanType
from pyspark.sql import Row
import csv
from pyspark.sql import SQLContext

def parseCSV(idx, part):
    if idx==0:
        part.next()
    for p in csv.reader(part):
        if p[0] == '2014':
            yield Row(YEAR = p[0],
                      MONTH = int(p[2]),
                      ORIGIN_CITY_NAME = p[15],
                      ORIGIN_AIRPORT_ID = p[11],
                      DEST_CITY_NAME = p[24],
                      DEST_AIRPORT_ID = p[20])
        elif p[0] == '2015':
            yield Row(YEAR = p[0],
                      MONTH = int(p[2])+12,
                      ORIGIN_CITY_NAME = p[15],
                      ORIGIN_AIRPORT_ID = p[11],
                      DEST_CITY_NAME = p[24],
                      DEST_AIRPORT_ID = p[20])
        elif p[0] == '2016':
            yield Row(YEAR = p[0],
                      MONTH = int(p[2])+24,
                      ORIGIN_CITY_NAME = p[15],
                      ORIGIN_AIRPORT_ID = p[11],
                      DEST_CITY_NAME = p[24],
                      DEST_AIRPORT_ID = p[20])
        else:
            pass

def main(sc):
	spark = HiveContext(sc)
	sqlContext = HiveContext(sc)
	rows = sc.textFile('../../lmf445/Flight_Project/Data/864625436_T_ONTIME_*2.csv').mapPartitionsWithIndex(parseCSV)
	df = sqlContext.createDataFrame(rows)
	
	flight_origin = \
    df.select('YEAR', 'MONTH', 'ORIGIN_CITY_NAME', 'ORIGIN_AIRPORT_ID') \
    .groupBy('YEAR', 'MONTH', 'ORIGIN_CITY_NAME') \
    .count() \
    .withColumnRenamed('count', 'origin_count')
	flight_origin = \
		flight_origin.withColumnRenamed('ORIGIN_CITY_NAME', 'City_of_Departure')

	flight_dest = \
		df.select('YEAR', 'MONTH', 'DEST_CITY_NAME', 'DEST_AIRPORT_ID') \
		.groupBy('YEAR', 'MONTH', 'DEST_CITY_NAME') \
		.count() \
		.withColumnRenamed('count', 'dest_count')
    
	flight_dest = flight_dest.withColumnRenamed('DEST_CITY_NAME', 'City_of_Arrival')
	flight_dest = flight_dest.withColumnRenamed('YEAR', 'YEAR_dest')
	flight_dest = flight_dest.withColumnRenamed('MONTH', 'MONTH_dest')
	
	total_counts = \
		flight_origin.join(flight_dest,
		((flight_origin.City_of_Departure==flight_dest.City_of_Arrival) & 
		(flight_origin.YEAR==flight_dest.YEAR_dest) & 
		(flight_origin.MONTH==flight_dest.MONTH_dest)))

	total_counts = \
		total_counts.select(total_counts.City_of_Departure.alias('City'),
		(total_counts.origin_count+total_counts.dest_count).alias('sum_counts'),
		'YEAR', 'MONTH')\
		
	total_counts_city_pivot = \
		total_counts.groupBy('City').pivot('MONTH').sum('sum_counts')
	
	total_counts_city_pivot.toPandas().to_csv('big_data_project/data/busiest_city.csv')

if __name__ == "__main__":
    sc = SparkContext()
    main(sc)